//SELECT TAGS
let rRange = document.querySelector('#r-range');
let gRange = document.querySelector('#g-range');
let bRange = document.querySelector('#b-range');
let bodyTag = document.querySelector('body');

let rangesbtn =document.querySelector('#random');
//GENERAL FUNCTIONS
function changeBackground (){
	
	let redRange = rRange.value;
    let greenRange = gRange.value;
    let blueRange = bRange.value;
  
    bodyTag.style.backgroundColor="rgb(" + redRange + "," + greenRange + "," + blueRange +")";
	};
	
function randomColor(){
	let numRandom1 = Math.floor(Math.random() * 255);
	let numRandom2 = Math.floor(Math.random() * 255);
    let numRandom3 = Math.floor(Math.random() * 255);
    
    let randomBack = [numRandom1,numRandom2,numRandom3];
    return randomBack;
		};

//START

rRange.addEventListener('input',function(){
	changeBackground()
	});
	
gRange.addEventListener('input',function(){
	changeBackground()
	});

bRange.addEventListener('input',function(){
	changeBackground()
	});
	


rangesbtn.addEventListener('click' , function(){
	let colors = randomColor()
    
    rRange.value=colors[0];
    gRange.value=colors[1];
    bRange.value=colors[2];
	
	changeBackground()
	}); 